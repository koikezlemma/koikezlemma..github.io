#include <stdio.h>

void WriteIndex(int* a, int n)
{
    for (int i = 0; i < n; i++) {
        a[i] = i;
    }
}

int main()
{
    // Init
    int N = 16;
    int* h_a = new int[N]; // on host (CPU)

    // Main
    WriteIndex(h_a, N);
    
    // Display results
    for (int i = 0; i < N; i++) {
        printf("%d\n",h_a[i]);
    }
    
    // Free memory
    delete [] h_a;
    
    return 0;
}

